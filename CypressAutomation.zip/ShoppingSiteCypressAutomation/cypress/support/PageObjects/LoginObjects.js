class LoginObjects
{
    ClickOnLogin()
    {
        return cy.get('.ico-login')
    }

    EnterEmailId()
    {
        return cy.get('#Email')
    }
    EnterPassword()
    {
        return cy.get('#Password')
    }

    ClickOnRememberCheckbox()
    {
        return cy.get('#RememberMe')
    }

    ClickLoginBtn()
    {
        return cy.get('form > .buttons > .button-1')
    }

}
export default LoginObjects;