class SearchProductObjects
{
    getSearchBox()
    {
        return cy.get('#small-searchterms')
    }

    clickSearchBtn()
    {
        return cy.get('#small-search-box-form > .button-1')
    }

    viewProduct()
    {
       return cy.get(':nth-child(2) > .product-item > .picture > a > img')
    }

    clickAddtoCart()
    {
        return cy.get(':nth-child(2) > .product-item > .details > .add-info > .buttons > .product-box-add-to-cart-button')
    }
    

    ViewCart()
    {
        return cy.get('#topcartlink > a > span.cart-label')
    }

    EnterQuantity()
    {
       return cy.get('.qty-input')
    }

    ClickOnUpdBtn(){
        return cy.get('#updatecart')
    }
}
export default SearchProductObjects;