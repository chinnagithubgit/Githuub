class RegistrationObjects
{
    clickOnRegister()
    {
        return cy.get('.ico-register')
    }

    setGender()
    {
        return cy.get('#gender-male')
    }

    setFirstName()
    {
        return cy.get('#FirstName')
    }

    setLastName()
    {
        return cy.get('#LastName')
    }

    setDate()
    {
        return cy.get('[name="DateOfBirthDay"]')
    }

    setMonth()
    {
        return cy.get('[name="DateOfBirthMonth"]')
    }

    setYear()
    {
        return cy.get('[name="DateOfBirthYear"]')
    }

    setEmail()
    {
        return cy.get('#Email')
    }

    setCompanyName()
    {
        return cy.get('#Company')
    }

    setNewLetterCheckBox()
    {
        return cy.get('#Newsletter')
    }

    setPassword()
    {
        return cy.get('#Password')
    }

    confirmPassword()
    {
        return cy.get('#ConfirmPassword')
    }

    setRegister()
     {
        return cy.get('#register-button')
     }

}
export default RegistrationObjects;
