///<reference types="cypress"/>
import LoginObjects from "../support/PageObjects/LoginObjects";


describe('Login Functionality',function(){
    it('Log into System',function(){
        const LoginObj=new LoginObjects()
        cy.visit("https://demo.nopcommerce.com/")
        LoginObj.ClickOnLogin().click()
        LoginObj.EnterEmailId().type("Navin@gmail.com");
        LoginObj.EnterPassword().type("Navin")
        LoginObj.ClickOnRememberCheckbox().check().should('be.checked').and('have.value','true')
        LoginObj.ClickLoginBtn().click();
    })
})