///<reference types="cypress"/>
import SearchProductObjects from "../support/PageObjects/SearchProductObjects";


describe('Search a Product and Add to cart',function(){
    it('Search Product',function(){
        var sum=0;
        const SearchObj=new SearchProductObjects()
        cy.visit("https://demo.nopcommerce.com/")
        SearchObj.getSearchBox().type('laptop')
        SearchObj.clickSearchBtn().click();
        SearchObj.viewProduct()
        SearchObj.clickAddtoCart().click()
        SearchObj.ViewCart().click()
        SearchObj.EnterQuantity().type(2)
        SearchObj.ClickOnUpdBtn().click()
        cy.get('.order-subtotal > .cart-total-right > .value-summary').each(($e1,index,$list)=>{
            const amount=$e1.text()
            var res=amount.split("")
            res=res[1].trim()
            sum=Number(sum)+Number(res)

        }).then(function(){
            cy.log(sum)
        })
        cy.get('.value-summary > strong').then(function(element){
            const amount=element.text();
            var res=amount.split("")
            var total=res[1].trim()
            expect(Number(total)).to.equal(sum)
        })
        

    })
})