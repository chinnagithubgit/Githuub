///<reference types="cypress"/>
import RegistrationObjects from "../support/PageObjects/RegistrationObjects";


describe('Registration Functionality',function(){
    before(function(){
        cy.fixture('example').then(function(data){
            this.data=data
        })
    })
    it('Register into System',function(){
       // Cypress.config('defaultCommandTimeout',8000)
        const RegObj=new RegistrationObjects()
        cy.visit("https://demo.nopcommerce.com/")
       
        RegObj.clickOnRegister().click()
       // RegObj.setGender().select(this.data.gender)
       RegObj.setGender().check().should('be.checked')
        RegObj.setFirstName().type(this.data.firstName)
        RegObj.setLastName().type(this.data.lastName)
        RegObj.setDate().select(this.data.date)
        RegObj.setMonth().select(this.data.month)
        //RegObj.setYear().select(this.data.year)
        RegObj.setYear().select('1999').should('have.value','1999') 
        RegObj.setEmail().type(this.data.email)
        RegObj.setCompanyName().type(this.data.companyName)
        RegObj.setNewLetterCheckBox().check().should('be.checked').and('have.value','true')
        RegObj.setPassword().type(this.data.password)
        RegObj.confirmPassword().type(this.data.confirmPassword)
       // cy.wait(10000)
       RegObj.setRegister().click()
       

 
    })
})